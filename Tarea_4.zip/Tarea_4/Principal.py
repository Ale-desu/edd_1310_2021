#lectura del archivo
from io import open
archivo= open("junio.dat","rt")
datos=archivo.readlines()
archivo.close()
#procesamiento del archivo
for j in range(0,len(datos),1):
  datos[j]=datos[j].replace("\n","").split(",")
datos.pop(0)
#manejo
class Array:
  def __init__(self,tam):
     self.__info=tam

  def get_item (self, posicion):
    dato=-1
    try:
      dato=self.__info[posicion]
    except Exception as e:
      print("error de posición")
      dato="error"
    return dato

  def get_item_esp (self, renglon, columna):
    esp=-1
    try:
      esp=self.__info[renglon][columna]
    except Exception as e:
      print("error de posición")
      esp="error"
    return esp

  def set_item(self,dato,posicion):
    try:
      self.__info[posicion]=dato
    except Exception as e:
      print("error")

  def get_lenght (self):
    return len(self.__info)

  def clear(self, dato):
    self.__info= [dato for x in range(len(self.__info))]

  def __iter__ (self):
    return iteradorArreglo(self.__info)

class iteradorArreglo:
  def __init__(self,arr):
    self.__arr=arr
    self.__indice =0

  def __iter__(self):
    return self

  def __next__(self):
    if self.__indice < len(self.__arr):
      dato=self.__arr[self.__indice]
      self.__indice +=1
      return dato
    else:
      raise StopIteration
algo=Array(datos)

class Sueldos:
  def __init__(self,empleados):
    self.__pagos=[0 for x in range(empleados)]
    self.__cantidad=empleados
    #print(self.__pagos)

  def horas_ex(self):
    horas=[0 for x in range(self.__cantidad)]
    for x in range(0,self.__cantidad,1):
      horas[x]=(float)(algo.get_item_esp(x,4))*276.5
    return horas

  def antiguedad(self):
    derecho=[0 for x in range(self.__cantidad)]
    for y in range(0,self.__cantidad,1):
      derecho[y]=((2020-((int)(algo.get_item_esp(y,6))))*.03)
    for x in range(0,self.__cantidad,1):
      derecho[x]=(float)(algo.get_item_esp(x,5))+((float)(algo.get_item_esp(x,5))*(float)(derecho[x]))
    return derecho

  def viejo (self):
    a=2
    b=2
    for x in range(0,self.__cantidad,1):
      anos= 2020 -((int)(algo.get_item_esp(x,6)))
      if anos > a :
        a=x
      elif anos< b:
        b=x
    print("el empleado mas antiguo es "+ algo.get_item_esp(a,1))
    print("el empleado mas nuevo es "+ algo.get_item_esp(b,1))

quincena=Sueldos(algo.get_lenght())
total1=quincena.antiguedad()
total2=quincena.horas_ex()
quincena.viejo()

pagos=[0 for x in range(algo.get_lenght())]

for x in range(0,algo.get_lenght(),1):
  pagos[x]=total1[x]+total2[x]
  print(" el empleado "+algo.get_item_esp(x,1)+" "+ algo.get_item_esp(x,2)+" recibira "+str(pagos[x]))
print("F")
